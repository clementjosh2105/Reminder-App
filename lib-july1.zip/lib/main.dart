import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'core/theme.dart';
import 'core/config/firebase_config.dart';
import 'services/storage_service.dart';
import 'services/notification_service.dart';
import 'services/firebase_notification_service.dart';
import 'services/motivation_service.dart';
import 'services/admob_service.dart';
import 'repositories/habit_repository.dart';
import 'providers/settings_provider.dart';
import 'providers/habit_provider.dart';
import 'screens/splash_screen.dart';

// ---------------------------------------------------------------------------
// Global service references — set once in main() before runApp().
// Providers read these directly; no override plumbing needed.
// ---------------------------------------------------------------------------
late final StorageService gStorageService;
late final NotificationService gNotificationService;
late final FirebaseNotificationService gFirebaseNotificationService;
late final AdMobService gAdMobService;
late final HabitRepository gHabitRepository;


void main() {
  // Catch synchronous errors thrown inside the Flutter framework itself.
  runZonedGuarded(_bootstrap, (error, stack) {
    debugPrint('🔴 Unhandled zone error: $error\n$stack');
  });
}

Future<void> _bootstrap() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Show the real error message in release mode instead of blank white screen.
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
    debugPrint('🔴 FlutterError: ${details.exception}\n${details.stack}');
  };

  // Override the default red error widget with one that works in release builds.
  ErrorWidget.builder = (FlutterErrorDetails details) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, color: Colors.red, size: 64),
                const SizedBox(height: 16),
                const Text(
                  'Something went wrong',
                  style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                Text(
                  details.exception.toString(),
                  style: const TextStyle(color: Colors.red, fontSize: 13),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  };

  // 1. Storage — must succeed for the app to function.
  gStorageService = StorageService();
  await gStorageService.init();

  // 1b. Initialize Firebase Core
  try {
    await Firebase.initializeApp(
      options: FirebaseConfig.currentPlatform,
    );
    debugPrint('Firebase Core initialized successfully');
  } catch (e, st) {
    debugPrint('⚠️ Firebase Core init failed (non-fatal): $e\n$st');
  }

  // 2. Notifications — Initialize Core Engine & Channels
  gNotificationService = NotificationService();
  bool permissionsGranted = false;
  try {
    await gNotificationService.init();
    // AWAIT the permission response completely before moving forward
    await gNotificationService.requestPermissions();
    permissionsGranted = true;
    debugPrint('Notification initialized successfully');
  } catch (e, st) {
    debugPrint('⚠️ NotificationService init failed (non-fatal): $e\n$st');
  }

  // 2b. Initialize Firebase Messaging (FCM)
  gFirebaseNotificationService = FirebaseNotificationService();
  try {
    await gFirebaseNotificationService.init();
    debugPrint('Firebase Messaging initialized successfully');
  } catch (e, st) {
    debugPrint('⚠️ FirebaseNotificationService init failed (non-fatal): $e\n$st');
  }

  // 3. AdMob — always non-fatal.
  gAdMobService = AdMobService();
  try {
    await gAdMobService.init();
  } catch (e, st) {
    debugPrint('⚠️ AdMobService init failed (non-fatal): $e\n$st');
  }

  // 4. Repository.
  gHabitRepository = HabitRepository(
    storageService: gStorageService,
    notificationService: gNotificationService,
    motivationService: MotivationService(),
    admobService: gAdMobService,
  );

  // 5. Reschedule existing reminders — ONLY if the engine is ready
  if (permissionsGranted) {
    try {
      await gHabitRepository.rescheduleAllActiveReminders();
      debugPrint('✅ Active reminders successfully rescheduled.');
    } catch (e, st) {
      debugPrint('⚠️ rescheduleAllActiveReminders failed (non-fatal): $e\n$st');
    }
  } else {
    debugPrint('⚠️ Skipped scheduling active reminders: Permissions not ready.');
  }

  runApp(
    ProviderScope(
      overrides: [
        storageServiceProvider.overrideWithValue(gStorageService),
        notificationServiceProvider.overrideWithValue(gNotificationService),
        admobServiceProvider.overrideWithValue(gAdMobService),
        habitRepositoryProvider.overrideWithValue(gHabitRepository),
      ],
      child: const MomentumApp(),
    ),
  );
}

class MomentumApp extends ConsumerWidget {
  const MomentumApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);

    final themeMode = switch (settings.themeMode) {
      'light' => ThemeMode.light,
      'dark'  => ThemeMode.dark,
      _       => ThemeMode.system,
    };

    return MaterialApp(
      title: 'Momentum',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: themeMode,
      home: const SplashScreen(),
    );
  }
}
