import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter_timezone/flutter_timezone.dart';
import '../models/habit.dart';

// Top-level callback for background notification actions.
// MUST be annotated with @pragma('vm:entry-point') to prevent tree shaking.
@pragma('vm:entry-point')
void notificationTapBackground(NotificationResponse notificationResponse) {
  debugPrint("Background Notification Action Tap: ${notificationResponse.actionId}");
}

class NotificationService {
  final FlutterLocalNotificationsPlugin _notificationsPlugin = FlutterLocalNotificationsPlugin();

  static const String channelId = 'momentum_reminders_channel';
  static const String channelName = 'Momentum Reminders';
  static const String channelDesc = 'Notifications for habit consistency';

  Future<void> init() async {
    // 1. Initialize Timezones
    tz.initializeTimeZones();
    try {
      final dynamic tzResult = await FlutterTimezone.getLocalTimezone();
      String timeZoneName = 'UTC';
      if (tzResult is String) {
        timeZoneName = tzResult;
      } else if (tzResult is Map) {
        timeZoneName = tzResult['identifier'] as String? ?? 'UTC';
      } else if (tzResult != null) {
        try {
          timeZoneName = (tzResult as dynamic).identifier as String? ?? 'UTC';
        } catch (_) {
          timeZoneName = tzResult.toString();
        }
      }
      tz.setLocalLocation(tz.getLocation(timeZoneName));
    } catch (e) {
      debugPrint('Failed to set local timezone location, falling back to UTC: $e');
      try {
        tz.setLocalLocation(tz.getLocation('UTC'));
      } catch (ex) {
        debugPrint('Failed to set UTC location: $ex');
      }
    }

    // 2. Configure Android Initialization Settings
    const AndroidInitializationSettings initializationSettingsAndroid =
    AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
    );

    // 3. Explicitly create the high importance channel for physical devices (like OnePlus)
    if (Platform.isAndroid) {
      final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
      _notificationsPlugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

      const AndroidNotificationChannel channel = AndroidNotificationChannel(
        channelId,
        channelName,
        description: channelDesc,
        importance: Importance.max, // Mandatory for heads-up banners on OnePlus
        playSound: true,
      );

      await androidImplementation?.createNotificationChannel(channel);
    }

    // 4. Initialize plugin
    await _notificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        debugPrint("🔔 Foreground Notification Action Tap Callback: ID=${response.id}, Action=${response.actionId}, Payload=${response.payload}");
        _notificationResponseController.value = response;
      },
      onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
    );
  }

  // ValueNotifier to allow repositories/providers to listen to notification taps in foreground
  static final ValueNotifier<NotificationResponse?> _notificationResponseController =
  ValueNotifier<NotificationResponse?>(null);

  static ValueNotifier<NotificationResponse?> get notificationTaps => _notificationResponseController;

  Future<void> requestPermissions() async {
    if (Platform.isAndroid) {
      final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
      _notificationsPlugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

      await androidImplementation?.requestNotificationsPermission();
      await androidImplementation?.requestExactAlarmsPermission();
    }
  }

  // Helper method to schedule notifications safely (falling back to inexact alarm if exact fails)
  Future<void> _safeZonedSchedule({
    required int id,
    required String? title,
    required String? body,
    required tz.TZDateTime scheduledDate,
    required NotificationDetails notificationDetails,
    required UILocalNotificationDateInterpretation uiLocalNotificationDateInterpretation,
    DateTimeComponents? matchDateTimeComponents,
    String? payload,
  }) async {
    AndroidScheduleMode scheduleMode = AndroidScheduleMode.exactAllowWhileIdle;

    if (Platform.isAndroid) {
      final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
      _notificationsPlugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

      // Check if the OS actually granted exact alarm permissions to avoid SecurityExceptions
      final bool? canScheduleExact = await androidImplementation?.canScheduleExactNotifications();

      if (canScheduleExact == false) {
        debugPrint("⚠️ Exact alarm permission missing on device. Falling back to inexact mode.");
        scheduleMode = AndroidScheduleMode.inexactAllowWhileIdle;
      }
    }

    try {
      debugPrint("⏰ [NotificationService] Scheduling notification (ID: $id): '$title' at $scheduledDate");
      await _notificationsPlugin.zonedSchedule(
        id,
        title,
        body,
        scheduledDate,
        notificationDetails,
        androidScheduleMode: scheduleMode,
        uiLocalNotificationDateInterpretation: uiLocalNotificationDateInterpretation,
        matchDateTimeComponents: matchDateTimeComponents,
        payload: payload,
      );
      debugPrint("✅ [NotificationService] Successfully scheduled notification (ID: $id)");
    } catch (e) {
      debugPrint('⚠️ Fallback due to unexpected error during scheduling: $e');
      await _notificationsPlugin.zonedSchedule(
        id,
        title,
        body,
        scheduledDate,
        notificationDetails,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: uiLocalNotificationDateInterpretation,
        matchDateTimeComponents: matchDateTimeComponents,
        payload: payload,
      );
      debugPrint("✅ [NotificationService] Successfully scheduled fallback notification (ID: $id)");
    }
  }

  // Main method to schedule notifications for a habit
  Future<void> scheduleHabit(Habit habit, String motivationMessage) async {
    await cancelHabit(habit.notificationId, habit.recurrenceType, habit.customDays.length);

    if (!habit.isEnabled) return;

    final timeParts = habit.timeOfDay.split(':');
    final int hour = int.parse(timeParts[0]);
    final int minute = int.parse(timeParts[1]);

    final AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      channelId,
      channelName,
      channelDescription: channelDesc,
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      styleInformation: BigTextStyleInformation(motivationMessage),
      actions: const <AndroidNotificationAction>[
        AndroidNotificationAction('action_done', 'Done', showsUserInterface: true),
        AndroidNotificationAction('action_snooze', 'Snooze 10m', showsUserInterface: true),
        AndroidNotificationAction('action_skip', 'Skip', showsUserInterface: true),
      ],
    );

    final NotificationDetails platformDetails = NotificationDetails(android: androidDetails);
    final payload = '${habit.id}|${habit.notificationId}';

    switch (habit.recurrenceType) {
      case 'Once':
        final scheduledTime = _nextInstanceOfTime(hour, minute);
        await _safeZonedSchedule(
          id: habit.notificationId,
          title: habit.title,
          body: motivationMessage,
          scheduledDate: scheduledTime,
          notificationDetails: platformDetails,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
          payload: payload,
        );
        break;

      case 'Daily':
        final scheduledTime = _nextInstanceOfTime(hour, minute);
        await _safeZonedSchedule(
          id: habit.notificationId,
          title: habit.title,
          body: motivationMessage,
          scheduledDate: scheduledTime,
          notificationDetails: platformDetails,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
          matchDateTimeComponents: DateTimeComponents.time,
          payload: payload,
        );
        break;

      case 'Weekdays':
        for (int day = 1; day <= 5; day++) {
          final scheduledTime = _nextInstanceOfDayOfWeekAndTime(day, hour, minute);
          final id = habit.notificationId * 10 + day;
          await _safeZonedSchedule(
            id: id,
            title: habit.title,
            body: motivationMessage,
            scheduledDate: scheduledTime,
            notificationDetails: platformDetails,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
            matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
            payload: payload,
          );
        }
        break;

      case 'Weekends':
        for (int day = 6; day <= 7; day++) {
          final scheduledTime = _nextInstanceOfDayOfWeekAndTime(day, hour, minute);
          final id = habit.notificationId * 10 + day;
          await _safeZonedSchedule(
            id: id,
            title: habit.title,
            body: motivationMessage,
            scheduledDate: scheduledTime,
            notificationDetails: platformDetails,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
            matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
            payload: payload,
          );
        }
        break;

      case 'CustomDays':
        for (final day in habit.customDays) {
          final scheduledTime = _nextInstanceOfDayOfWeekAndTime(day, hour, minute);
          final id = habit.notificationId * 10 + day;
          await _safeZonedSchedule(
            id: id,
            title: habit.title,
            body: motivationMessage,
            scheduledDate: scheduledTime,
            notificationDetails: platformDetails,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
            matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
            payload: payload,
          );
        }
        break;

      case 'Hourly':
        final int interval = habit.hourlyInterval > 0 ? habit.hourlyInterval : 2;
        int currentHour = hour;
        int slotIndex = 0;

        while (currentHour <= 22) {
          final scheduledTime = _nextInstanceOfTime(currentHour, minute);
          final id = habit.notificationId * 100 + slotIndex;

          await _safeZonedSchedule(
            id: id,
            title: habit.title,
            body: motivationMessage,
            scheduledDate: scheduledTime,
            notificationDetails: platformDetails,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
            matchDateTimeComponents: DateTimeComponents.time,
            payload: payload,
          );

          currentHour += interval;
          slotIndex++;
        }
        break;
    }
  }

  Future<void> snooze(Habit habit, int snoozeMinutes, String motivationMessage) async {
    final AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      channelId,
      channelName,
      channelDescription: channelDesc,
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      styleInformation: BigTextStyleInformation(motivationMessage),
      actions: const <AndroidNotificationAction>[
        AndroidNotificationAction('action_done', 'Done', showsUserInterface: true),
        AndroidNotificationAction('action_snooze', 'Snooze 10m', showsUserInterface: true),
        AndroidNotificationAction('action_skip', 'Skip', showsUserInterface: true),
      ],
    );

    final NotificationDetails platformDetails = NotificationDetails(android: androidDetails);
    final int snoozeId = habit.notificationId + 999999;
    final scheduledTime = tz.TZDateTime.now(tz.local).add(Duration(minutes: snoozeMinutes));

    await _safeZonedSchedule(
      id: snoozeId,
      title: "${habit.title} (Snoozed)",
      body: motivationMessage,
      scheduledDate: scheduledTime,
      notificationDetails: platformDetails,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      payload: '${habit.id}|$snoozeId',
    );
  }

  Future<void> cancelHabit(int baseId, String recurrenceType, int customDaysCount) async {
    debugPrint("🚫 [NotificationService] Canceling notifications for baseId: $baseId");
    await _notificationsPlugin.cancel(baseId);
    await _notificationsPlugin.cancel(baseId + 999999);

    if (recurrenceType == 'Weekdays' || recurrenceType == 'Weekends' || recurrenceType == 'CustomDays') {
      for (int i = 1; i <= 7; i++) {
        await _notificationsPlugin.cancel(baseId * 10 + i);
      }
    }

    if (recurrenceType == 'Hourly') {
      for (int slot = 0; slot < 24; slot++) {
        await _notificationsPlugin.cancel(baseId * 100 + slot);
      }
    }
  }

  tz.TZDateTime _nextInstanceOfTime(int hour, int minute) {
    final tz.TZDateTime now = tz.TZDateTime.now(tz.local);
    tz.TZDateTime scheduledDate = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }
    return scheduledDate;
  }

  tz.TZDateTime _nextInstanceOfDayOfWeekAndTime(int dayOfWeek, int hour, int minute) {
    tz.TZDateTime scheduledDate = _nextInstanceOfTime(hour, minute);
    while (scheduledDate.weekday != dayOfWeek) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }
    return scheduledDate;
  }
}