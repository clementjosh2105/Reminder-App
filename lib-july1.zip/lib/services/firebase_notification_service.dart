import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/config/firebase_config.dart';

// Top-level background message handler for FCM.
// MUST be annotated with @pragma('vm:entry-point') to prevent tree shaking.
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Initialize Firebase for background isolate if not already initialized
  await Firebase.initializeApp(options: FirebaseConfig.currentPlatform);
  debugPrint("Handling background FCM message: ${message.messageId}");
}

class FirebaseNotificationService {
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;

  Future<void> init() async {
    // 1. Set background messaging handler
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

    // 2. Request Permissions
    await requestPermissions();

    // 3. Configure foreground notification presentation options
    await _fcm.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );

    // 4. Retrieve FCM Token
    await retrieveAndSaveToken();

    // 5. Handle foreground messages
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      debugPrint('🔔 Foreground FCM Message received: ${message.notification?.title}');
    });

    // 6. Handle app opened via notification (when app is in background but not killed)
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      debugPrint('📩 Notification clicked & opened app from background: ${message.data}');
    });

    // 7. Handle app opened via notification (when app was completely terminated)
    RemoteMessage? initialMessage = await _fcm.getInitialMessage();
    if (initialMessage != null) {
      debugPrint('📩 App opened from fully terminated state via FCM: ${initialMessage.data}');
    }

    // 8. Listen to token refresh
    _fcm.onTokenRefresh.listen((newToken) async {
      debugPrint('🔄 FCM Token refreshed: $newToken');
      await _saveTokenToFirestore(newToken);
    });
  }

  Future<void> requestPermissions() async {
    NotificationSettings settings = await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );
    debugPrint('🔔 User notification permission status: ${settings.authorizationStatus}');
  }

  Future<void> retrieveAndSaveToken() async {
    try {
      String? token = await _fcm.getToken();
      if (token != null) {
        debugPrint('🔑 FCM Registration Token: $token');
        await _saveTokenToFirestore(token);
      }
    } catch (e) {
      debugPrint('⚠️ Error retrieving FCM Token: $e');
    }
  }

  Future<void> _saveTokenToFirestore(String token) async {
    try {
      // Stores device token along with metadata
      final docRef = FirebaseFirestore.instance.collection('device_tokens').doc(token);
      await docRef.set({
        'token': token,
        'lastUpdated': FieldValue.serverTimestamp(),
        'platform': defaultTargetPlatform.toString(),
      });
      debugPrint('✅ FCM Token synced to Firestore.');
    } catch (e) {
      debugPrint('⚠️ Failed to sync FCM Token to Firestore: $e');
    }
  }
}
