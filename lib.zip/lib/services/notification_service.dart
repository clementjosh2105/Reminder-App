import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter_timezone/flutter_timezone.dart';
import '../models/habit.dart';

// Top-level callback for background notification actions.
// MUST be annotated with @pragma('vm:entry-point') to prevent tree shaking.
@pragma('vm:entry-point')
void notificationTapBackground(NotificationResponse notificationResponse) {
  debugPrint("Background Notification Action Tap: ${notificationResponse.actionId}");
  // We handle actions via a broadcast or direct calls if needed, 
  // but to keep it simple and stable, we can let the UI capture the tap when it resumes,
  // or handle background operations. We will parse the payload and handle it.
}

class NotificationService {
  final FlutterLocalNotificationsPlugin _notificationsPlugin = FlutterLocalNotificationsPlugin();

  static const String channelId = 'momentum_reminders_channel';
  static const String channelName = 'Momentum Reminders';
  static const String channelDesc = 'Notifications for habit consistency';

  Future<void> init() async {
    // 1. Initialize Timezones
    tz.initializeTimeZones();
    try {
      final dynamic tzResult = await FlutterTimezone.getLocalTimezone();
      String timeZoneName = 'UTC';
      if (tzResult is String) {
        timeZoneName = tzResult;
      } else if (tzResult is Map) {
        timeZoneName = tzResult['identifier'] as String? ?? 'UTC';
      } else if (tzResult != null) {
        try {
          timeZoneName = (tzResult as dynamic).identifier as String? ?? 'UTC';
        } catch (_) {
          timeZoneName = tzResult.toString();
        }
      }
      tz.setLocalLocation(tz.getLocation(timeZoneName));
    } catch (e) {
      debugPrint('Failed to set local timezone location, falling back to UTC: $e');
      try {
        tz.setLocalLocation(tz.getLocation('UTC'));
      } catch (ex) {
        debugPrint('Failed to set UTC location: $ex');
      }
    }

    // 2. Configure Android Initialization Settings
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
    );

    // 3. Initialize plugin
    await _notificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        debugPrint("🔔 Foreground Notification Action Tap Callback: ID=${response.id}, Action=${response.actionId}, Payload=${response.payload}");
        // Handled in the UI/App state manager via streams or static listeners
        _notificationResponseController.value = response;
      },
      onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
    );
  }

  // ValueNotifier to allow repositories/providers to listen to notification taps in foreground
  static final ValueNotifier<NotificationResponse?> _notificationResponseController =
      ValueNotifier<NotificationResponse?>(null);
  
  static ValueNotifier<NotificationResponse?> get notificationTaps => _notificationResponseController;

  Future<void> requestPermissions() async {
    if (Platform.isAndroid) {
      final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
          _notificationsPlugin.resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>();
      
      await androidImplementation?.requestNotificationsPermission();
      await androidImplementation?.requestExactAlarmsPermission();
    }
  }

  // Helper method to schedule notifications safely (falling back to inexact alarm if exact fails)
  Future<void> _safeZonedSchedule({
    required int id,
    required String? title,
    required String? body,
    required tz.TZDateTime scheduledDate,
    required NotificationDetails notificationDetails,
    required UILocalNotificationDateInterpretation uiLocalNotificationDateInterpretation,
    DateTimeComponents? matchDateTimeComponents,
    String? payload,
  }) async {
    try {
      debugPrint("⏰ [NotificationService] Scheduling notification (ID: $id): '$title' at $scheduledDate (Local Timezone: ${scheduledDate.location.name})");
      await _notificationsPlugin.zonedSchedule(
        id,
        title,
        body,
        scheduledDate,
        notificationDetails,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: uiLocalNotificationDateInterpretation,
        matchDateTimeComponents: matchDateTimeComponents,
        payload: payload,
      );
      debugPrint("✅ [NotificationService] Successfully scheduled notification (ID: $id)");
    } catch (e) {
      debugPrint('⚠️ Fallback to inexact schedule due to exact alarm limitation: $e');
      await _notificationsPlugin.zonedSchedule(
        id,
        title,
        body,
        scheduledDate,
        notificationDetails,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: uiLocalNotificationDateInterpretation,
        matchDateTimeComponents: matchDateTimeComponents,
        payload: payload,
      );
      debugPrint("✅ [NotificationService] Successfully scheduled fallback notification (ID: $id)");
    }
  }

  // Main method to schedule notifications for a habit
  Future<void> scheduleHabit(Habit habit, String motivationMessage) async {
    // First, cancel any existing notifications for this habit
    await cancelHabit(habit.notificationId, habit.recurrenceType, habit.customDays.length);

    if (!habit.isEnabled) return;

    final timeParts = habit.timeOfDay.split(':');
    final int hour = int.parse(timeParts[0]);
    final int minute = int.parse(timeParts[1]);

    final AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      channelId,
      channelName,
      channelDescription: channelDesc,
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      styleInformation: BigTextStyleInformation(motivationMessage),
      actions: const <AndroidNotificationAction>[
        AndroidNotificationAction('action_done', 'Done', showsUserInterface: true),
        AndroidNotificationAction('action_snooze', 'Snooze 10m', showsUserInterface: true),
        AndroidNotificationAction('action_skip', 'Skip', showsUserInterface: true),
      ],
    );

    final NotificationDetails platformDetails = NotificationDetails(android: androidDetails);

    final payload = '${habit.id}|${habit.notificationId}';

    switch (habit.recurrenceType) {
      case 'Once':
        final scheduledTime = _nextInstanceOfTime(hour, minute);
        await _safeZonedSchedule(
          id: habit.notificationId,
          title: habit.title,
          body: motivationMessage,
          scheduledDate: scheduledTime,
          notificationDetails: platformDetails,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
          payload: payload,
        );
        break;

      case 'Daily':
        final scheduledTime = _nextInstanceOfTime(hour, minute);
        await _safeZonedSchedule(
          id: habit.notificationId,
          title: habit.title,
          body: motivationMessage,
          scheduledDate: scheduledTime,
          notificationDetails: platformDetails,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
          matchDateTimeComponents: DateTimeComponents.time,
          payload: payload,
        );
        break;

      case 'Weekdays':
        // Schedule weekly notifications for Monday (1) through Friday (5)
        for (int day = 1; day <= 5; day++) {
          final scheduledTime = _nextInstanceOfDayOfWeekAndTime(day, hour, minute);
          final id = habit.notificationId * 10 + day;
          await _safeZonedSchedule(
            id: id,
            title: habit.title,
            body: motivationMessage,
            scheduledDate: scheduledTime,
            notificationDetails: platformDetails,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
            matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
            payload: payload,
          );
        }
        break;

      case 'Weekends':
        // Schedule weekly notifications for Saturday (6) and Sunday (7)
        for (int day = 6; day <= 7; day++) {
          final scheduledTime = _nextInstanceOfDayOfWeekAndTime(day, hour, minute);
          final id = habit.notificationId * 10 + day;
          await _safeZonedSchedule(
            id: id,
            title: habit.title,
            body: motivationMessage,
            scheduledDate: scheduledTime,
            notificationDetails: platformDetails,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
            matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
            payload: payload,
          );
        }
        break;

      case 'CustomDays':
        // Schedule weekly notifications for each custom day (1 = Monday, 7 = Sunday)
        for (final day in habit.customDays) {
          final scheduledTime = _nextInstanceOfDayOfWeekAndTime(day, hour, minute);
          final id = habit.notificationId * 10 + day;
          await _safeZonedSchedule(
            id: id,
            title: habit.title,
            body: motivationMessage,
            scheduledDate: scheduledTime,
            notificationDetails: platformDetails,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
            matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
            payload: payload,
          );
        }
        break;

      case 'Hourly':
        // Schedule multiple notifications starting from start time, spaced by X hours.
        // To be realistic and prevent overflow, we schedule slots from start hour to 10 PM.
        final int interval = habit.hourlyInterval > 0 ? habit.hourlyInterval : 2;
        int currentHour = hour;
        int slotIndex = 0;
        
        while (currentHour <= 22) { // Stop at 10 PM
          final scheduledTime = _nextInstanceOfTime(currentHour, minute);
          final id = habit.notificationId * 100 + slotIndex;
          
          await _safeZonedSchedule(
            id: id,
            title: habit.title,
            body: motivationMessage,
            scheduledDate: scheduledTime,
            notificationDetails: platformDetails,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
            matchDateTimeComponents: DateTimeComponents.time,
            payload: payload,
          );
          
          currentHour += interval;
          slotIndex++;
        }
        break;
    }
  }

  // Snooze a notification by X minutes
  Future<void> snooze(Habit habit, int snoozeMinutes, String motivationMessage) async {
    final AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      channelId,
      channelName,
      channelDescription: channelDesc,
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      styleInformation: BigTextStyleInformation(motivationMessage),
      actions: const <AndroidNotificationAction>[
        AndroidNotificationAction('action_done', 'Done', showsUserInterface: true),
        AndroidNotificationAction('action_snooze', 'Snooze 10m', showsUserInterface: true),
        AndroidNotificationAction('action_skip', 'Skip', showsUserInterface: true),
      ],
    );

    final NotificationDetails platformDetails = NotificationDetails(android: androidDetails);
    
    // We schedule a one-off notification for 'snoozeMinutes' in the future.
    // Use a unique notification ID for the snooze to avoid canceling the recurring parent.
    final int snoozeId = habit.notificationId + 999999; 
    final scheduledTime = tz.TZDateTime.now(tz.local).add(Duration(minutes: snoozeMinutes));

    await _safeZonedSchedule(
      id: snoozeId,
      title: "${habit.title} (Snoozed)",
      body: motivationMessage,
      scheduledDate: scheduledTime,
      notificationDetails: platformDetails,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      payload: '${habit.id}|$snoozeId',
    );
  }

  // Cancel notifications for a habit
  Future<void> cancelHabit(int baseId, String recurrenceType, int customDaysCount) async {
    debugPrint("🚫 [NotificationService] Canceling notifications for baseId: $baseId (recurrence: $recurrenceType)");
    // 1. Cancel main/once/daily ID
    await _notificationsPlugin.cancel(baseId);
    
    // 2. Cancel snooze ID if active
    await _notificationsPlugin.cancel(baseId + 999999);

    // 3. Cancel custom days / weekdays / weekends
    if (recurrenceType == 'Weekdays' || recurrenceType == 'Weekends' || recurrenceType == 'CustomDays') {
      for (int i = 1; i <= 7; i++) {
        await _notificationsPlugin.cancel(baseId * 10 + i);
      }
    }

    // 4. Cancel hourly slots
    if (recurrenceType == 'Hourly') {
      for (int slot = 0; slot < 24; slot++) {
        await _notificationsPlugin.cancel(baseId * 100 + slot);
      }
    }
  }

  // --- TIME CALCULATION HELPERS ---

  tz.TZDateTime _nextInstanceOfTime(int hour, int minute) {
    final tz.TZDateTime now = tz.TZDateTime.now(tz.local);
    tz.TZDateTime scheduledDate = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }
    return scheduledDate;
  }

  tz.TZDateTime _nextInstanceOfDayOfWeekAndTime(int dayOfWeek, int hour, int minute) {
    tz.TZDateTime scheduledDate = _nextInstanceOfTime(hour, minute);
    while (scheduledDate.weekday != dayOfWeek) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }
    return scheduledDate;
  }
}
