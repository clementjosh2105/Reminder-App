import 'package:hive_flutter/hive_flutter.dart';
import '../models/habit.dart';

class StorageService {
  static const String _habitsBoxName = 'habits_box_v1';
  static const String _settingsBoxName = 'settings_box_v1';

  late Box<Habit> _habitsBox;
  late Box _settingsBox;

  // Initialize Hive and open necessary boxes
  Future<void> init() async {
    await Hive.initFlutter();
    
    // Register adapters only if not already registered
    if (!Hive.isAdapterRegistered(0)) {
      Hive.registerAdapter(HabitAdapter());
    }
    
    _habitsBox = await Hive.openBox<Habit>(_habitsBoxName);
    _settingsBox = await Hive.openBox(_settingsBoxName);
  }

  // --- HABIT OPERATIONS ---
  
  List<Habit> getHabits() {
    return _habitsBox.values.toList();
  }

  Future<void> saveHabit(Habit habit) async {
    await _habitsBox.put(habit.id, habit);
  }

  Future<void> deleteHabit(String id) async {
    await _habitsBox.delete(id);
  }

  Future<void> clearAllData() async {
    await _habitsBox.clear();
    await _settingsBox.clear();
  }

  // --- SETTINGS & CONFIG OPERATIONS ---

  String getThemeMode() {
    return _settingsBox.get('theme_mode', defaultValue: 'system') as String;
  }

  Future<void> setThemeMode(String themeMode) async {
    await _settingsBox.put('theme_mode', themeMode);
  }

  bool getNotificationSound() {
    return _settingsBox.get('notification_sound', defaultValue: true) as bool;
  }

  Future<void> setNotificationSound(bool enabled) async {
    await _settingsBox.put('notification_sound', enabled);
  }

  String getMotivationPersonality() {
    return _settingsBox.get('motivation_personality', defaultValue: 'Friendly') as String;
  }

  Future<void> setMotivationPersonality(String personality) async {
    await _settingsBox.put('motivation_personality', personality);
  }

  bool hasCompletedOnboarding() {
    return _settingsBox.get('completed_onboarding', defaultValue: false) as bool;
  }

  Future<void> setCompletedOnboarding(bool completed) async {
    await _settingsBox.put('completed_onboarding', completed);
  }

  bool getShowAds() {
    return _settingsBox.get('show_ads', defaultValue: true) as bool;
  }

  Future<void> setShowAds(bool value) async {
    await _settingsBox.put('show_ads', value);
  }

  DateTime? getLastInterstitialShownTime() {
    final ms = _settingsBox.get('last_interstitial_shown_time') as int?;
    return ms != null ? DateTime.fromMillisecondsSinceEpoch(ms) : null;
  }

  Future<void> setLastInterstitialShownTime(DateTime time) async {
    await _settingsBox.put('last_interstitial_shown_time', time.millisecondsSinceEpoch);
  }
}
