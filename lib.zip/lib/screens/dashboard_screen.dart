import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:intl/intl.dart';
import '../core/constants.dart';
import '../providers/habit_provider.dart';
import '../providers/settings_provider.dart';
import '../models/habit.dart';
import '../services/notification_service.dart';
import 'habit_list_screen.dart';
import 'statistics_screen.dart';
import 'settings_screen.dart';
import 'create_edit_habit_screen.dart';

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  int _currentIndex = 0;
  BannerAd? _bannerAd;
  bool _isBannerLoaded = false;
  bool _isBannerLoading = false;
  bool _isAdDismissed = false;
  double? _loadedAdWidth;
  String _motivationalQuote = '';

  @override
  void initState() {
    super.initState();
    _getRandomQuote();
    
    // Listen to notification action taps
    NotificationService.notificationTaps.addListener(_handleNotificationTap);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final showAds = ref.read(settingsProvider).showAds;
    if (showAds) {
      _loadBannerAd();
    } else {
      _disposeBannerAd();
    }
  }

  @override
  void dispose() {
    _disposeBannerAd();
    NotificationService.notificationTaps.removeListener(_handleNotificationTap);
    super.dispose();
  }

  void _getRandomQuote() {
    final list = AppConstants.defaultQuotes;
    _motivationalQuote = list[DateTime.now().day % list.length];
  }

  void _disposeBannerAd() {
    _bannerAd?.dispose();
    _bannerAd = null;
    _isBannerLoaded = false;
    _isBannerLoading = false;
    _loadedAdWidth = null;
  }

  void _loadBannerAd() async {
    final showAds = ref.read(settingsProvider).showAds;
    if (!showAds) return;

    final currentWidth = MediaQuery.of(context).size.width;
    if (_bannerAd != null && _loadedAdWidth == currentWidth) return;

    if (_isBannerLoading) return;
    _isBannerLoading = true;

    // If width changed, dispose the old ad first
    if (_bannerAd != null) {
      _disposeBannerAd();
    }

    final adMobService = ref.read(admobServiceProvider);
    await adMobService.init();
    if (!mounted) {
      _isBannerLoading = false;
      return;
    }

    try {
      final adSize = await AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(currentWidth.truncate());
      final finalAdSize = adSize ?? AdSize.banner;

      if (!mounted) {
        _isBannerLoading = false;
        return;
      }

      _bannerAd = adMobService.createBannerAd(
        size: finalAdSize,
        onAdLoaded: () {
          if (!mounted) return;
          setState(() {
            _isBannerLoaded = true;
            _isBannerLoading = false;
            _loadedAdWidth = currentWidth;
            _isAdDismissed = false;
          });
        },
        onAdFailedToLoad: (ad, error) {
          if (!mounted) return;
          setState(() {
            _isBannerLoaded = false;
            _isBannerLoading = false;
            _bannerAd = null;
            _loadedAdWidth = null;
          });
        },
      )..load();
    } catch (e) {
      debugPrint("Failed to load adaptive banner ad: $e");
      if (mounted) {
        setState(() {
          _isBannerLoading = false;
          _bannerAd = null;
          _loadedAdWidth = null;
        });
      }
    }
  }

  void _handleNotificationTap() {
    final response = NotificationService.notificationTaps.value;
    if (response == null) return;
    
    final payload = response.payload;
    if (payload != null && payload.contains('|')) {
      final parts = payload.split('|');
      final String habitId = parts[0];
      
      // Reset the tap so it doesn't trigger again
      NotificationService.notificationTaps.value = null;

      // Show completion flow dialog for this habit
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showCompletionFlowDialog(habitId, response.actionId);
      });
    }
  }

  void _showCompletionFlowDialog(String habitId, String? actionId) {
    final habits = ref.read(habitNotifierProvider);
    final habitIndex = habits.indexWhere((h) => h.id == habitId);
    if (habitIndex == -1) return;
    
    final habit = habits[habitIndex];

    // If an action was tapped directly from the notification buttons
    if (actionId == 'action_done') {
      ref.read(habitNotifierProvider.notifier).completeHabit(habit.id, DateTime.now());
      _showToast("Great job! Habit completed.");
      return;
    } else if (actionId == 'action_snooze') {
      ref.read(habitNotifierProvider.notifier).snoozeHabit(habit.id, 10);
      _showToast("Snoozed for 10 minutes.");
      return;
    } else if (actionId == 'action_skip') {
      ref.read(habitNotifierProvider.notifier).skipHabit(habit.id);
      _showToast("Habit skipped for today.");
      return;
    }

    // Otherwise show the dialog popup
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              Icon(
                AppConstants.getCategoryIcon(habit.category),
                color: AppConstants.getCategoryColor(habit.category),
              ),
              const SizedBox(width: 12),
              Expanded(child: Text(habit.title)),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                habit.description,
                style: const TextStyle(fontStyle: FontStyle.italic),
              ),
              const SizedBox(height: 16),
              const Text("Did you complete this habit today?"),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                ref.read(habitNotifierProvider.notifier).skipHabit(habit.id);
                Navigator.of(context).pop();
                _showToast("Habit skipped.");
              },
              child: const Text("Skip"),
            ),
            TextButton(
              onPressed: () {
                ref.read(habitNotifierProvider.notifier).snoozeHabit(habit.id, 10);
                Navigator.of(context).pop();
                _showToast("Snoozed for 10 minutes.");
              },
              child: const Text("Snooze (10m)"),
            ),
            if (habit.isCompletedToday())
              ElevatedButton(
                onPressed: () {
                  ref.read(habitNotifierProvider.notifier).uncompleteHabit(habit.id, DateTime.now());
                  Navigator.of(context).pop();
                  _showToast("Habit uncompleted.");
                },
                child: const Text("Undo Done"),
              )
            else
              ElevatedButton(
                onPressed: () {
                  ref.read(habitNotifierProvider.notifier).completeHabit(habit.id, DateTime.now());
                  Navigator.of(context).pop();
                  _showToast("Awesome! Keep it up.");
                },
                child: const Text("Done"),
              ),
          ],
        );
      },
    );
  }

  void _showToast(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final todayHabits = ref.watch(todayHabitsProvider);
    final completionRate = ref.watch(todayCompletionRateProvider);
    final stats = ref.watch(streakStatsProvider);
    
    // Listen to changes in the showAds setting reactively
    ref.listen<bool>(
      settingsProvider.select((s) => s.showAds),
      (previous, next) {
        if (next) {
          _loadBannerAd();
        } else {
          _disposeBannerAd();
        }
      },
    );

    // Sidebar navigation screens list
    final List<Widget> screens = [
      _buildHomeDashboard(theme, todayHabits, completionRate, stats),
      const HabitListScreen(),
      const StatisticsScreen(),
      const SettingsScreen(),
    ];

    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: screens[_currentIndex],
          ),
          if (_currentIndex == 0 && _isBannerLoaded && _bannerAd != null && !_isAdDismissed)
            SafeArea(
              top: false,
              bottom: false,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    color: theme.scaffoldBackgroundColor,
                    alignment: Alignment.center,
                    width: double.infinity,
                    height: _bannerAd!.size.height.toDouble() + 14.0,
                    padding: const EdgeInsets.only(top: 14.0),
                    child: SizedBox(
                      width: _bannerAd!.size.width.toDouble(),
                      height: _bannerAd!.size.height.toDouble(),
                      child: AdWidget(ad: _bannerAd!),
                    ),
                  ),
                  Positioned(
                    top: 0.0,
                    right: 8.0,
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          _isAdDismissed = true;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.all(3.0),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.surface.withOpacity(0.9),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: theme.colorScheme.onSurface.withOpacity(0.12),
                            width: 1.0,
                          ),
                        ),
                        child: Icon(
                          Icons.close_rounded,
                          size: 14.0,
                          color: theme.colorScheme.onSurface.withOpacity(0.7),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_rounded),
            label: 'Dashboard',
          ),
          NavigationDestination(
            icon: Icon(Icons.list_alt_rounded),
            label: 'Habits',
          ),
          NavigationDestination(
            icon: Icon(Icons.analytics_rounded),
            label: 'Stats',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_rounded),
            label: 'Settings',
          ),
        ],
      ),
      floatingActionButton: _currentIndex == 0 || _currentIndex == 1
          ? FloatingActionButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const CreateEditHabitScreen()),
                );
              },
              child: const Icon(Icons.add_rounded),
            )
          : null,
      floatingActionButtonLocation: _currentIndex == 0 && _isBannerLoaded && _bannerAd != null && !_isAdDismissed
          ? _AdAdjustedFabLocation(
              FloatingActionButtonLocation.endFloat,
              _bannerAd!.size.height.toDouble() + 22.0,
            )
          : FloatingActionButtonLocation.endFloat,
    );
  }

  Widget _buildHomeDashboard(
    ThemeData theme,
    List<Habit> todayHabits,
    double completionRate,
    StreakStats stats,
  ) {
    final dateStr = DateFormat('EEEE, MMMM d').format(DateTime.now());

    return CustomScrollView(
      slivers: [
        SliverAppBar(
          expandedHeight: 80.0,
          floating: false,
          pinned: true,
          backgroundColor: theme.scaffoldBackgroundColor,
          flexibleSpace: FlexibleSpaceBar(
            title: Text(
              AppConstants.appName,
              style: TextStyle(
                color: theme.colorScheme.onBackground,
                fontWeight: FontWeight.bold,
              ),
            ),
            centerTitle: false,
            titlePadding: const EdgeInsets.only(left: 20, bottom: 16),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Text(
                dateStr,
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            )
          ],
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Quote Card
                _buildQuoteCard(theme),
                const SizedBox(height: 24),
                
                // Circular Progress Card
                _buildProgressCard(theme, todayHabits, completionRate),
                const SizedBox(height: 24),

                // Streak Grid
                _buildStreakGrid(theme, stats),
                const SizedBox(height: 24),

                // Checklist Section
                const Text(
                  "Today's Habit Checklist",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                
                if (todayHabits.isEmpty)
                  _buildEmptyState(theme)
                else
                  ...todayHabits.map((habit) => _buildHabitChecklistItem(theme, habit)),
                
                const SizedBox(height: 32),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildQuoteCard(ThemeData theme) {
    return Card(
      elevation: 0,
      color: theme.colorScheme.primary.withOpacity(0.05),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: theme.colorScheme.primary.withOpacity(0.1)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Row(
          children: [
            Icon(
              Icons.format_quote_rounded,
              size: 40,
              color: theme.colorScheme.primary.withOpacity(0.3),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _motivationalQuote,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  fontStyle: FontStyle.italic,
                  color: theme.colorScheme.primary,
                  height: 1.4,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressCard(ThemeData theme, List<Habit> todayHabits, double rate) {
    final percentage = (rate * 100).toInt();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Row(
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 90,
                  height: 90,
                  child: CircularProgressIndicator(
                    value: rate,
                    strokeWidth: 10,
                    backgroundColor: theme.colorScheme.primary.withOpacity(0.1),
                    color: theme.colorScheme.primary,
                    strokeCap: StrokeCap.round,
                  ),
                ),
                Text(
                  "$percentage%",
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(width: 24),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Today's Progress",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    todayHabits.isEmpty
                        ? "No habits scheduled for today."
                        : "${todayHabits.where((h) => h.isCompletedToday()).length} of ${todayHabits.length} habits completed",
                    style: TextStyle(
                      fontSize: 14,
                      color: theme.colorScheme.onSurface.withOpacity(0.6),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    rate >= 1.0 
                        ? "Awesome! Perfect score!" 
                        : rate >= 0.5 
                            ? "Over halfway there, keep going!" 
                            : "Start your momentum for today!",
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStreakGrid(ThemeData theme, StreakStats stats) {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            theme,
            "Current Streak",
            "${stats.currentStreak} Days",
            Icons.local_fire_department_rounded,
            Colors.orange,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: _buildStatCard(
            theme,
            "Longest Streak",
            "${stats.longestStreak} Days",
            Icons.emoji_events_rounded,
            Colors.amber.shade700,
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard(
    ThemeData theme,
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 13,
                    color: theme.colorScheme.onSurface.withOpacity(0.6),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Icon(icon, color: color, size: 24),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              value,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 32),
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.05),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Icon(Icons.check_circle_outline_rounded, size: 48, color: Colors.grey.shade400),
          const SizedBox(height: 12),
          Text(
            "Free day! Nothing scheduled.",
            style: TextStyle(
              fontSize: 15,
              color: theme.colorScheme.onSurface.withOpacity(0.6),
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHabitChecklistItem(ThemeData theme, Habit habit) {
    final completed = habit.isCompletedToday();

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: completed 
              ? theme.colorScheme.primary.withOpacity(0.1) 
              : theme.colorScheme.onSurface.withOpacity(0.1)
        ),
      ),
      color: completed 
          ? theme.colorScheme.primary.withOpacity(0.08) 
          : theme.colorScheme.surface,
      child: ListTile(
        onTap: () => _showCompletionFlowDialog(habit.id, null),
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: AppConstants.getCategoryColor(habit.category).withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(
            AppConstants.getCategoryIcon(habit.category),
            color: AppConstants.getCategoryColor(habit.category),
          ),
        ),
        title: Text(
          habit.title,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            decoration: completed ? TextDecoration.lineThrough : null,
            color: completed ? theme.colorScheme.onSurface.withOpacity(0.4) : theme.colorScheme.onSurface,
          ),
        ),
        subtitle: Text(
          "${habit.timeOfDay} • ${habit.recurrenceType}",
          style: TextStyle(color: theme.colorScheme.onSurface.withOpacity(0.6), fontSize: 13),
        ),
        trailing: InkWell(
          onTap: () {
            if (completed) {
              ref.read(habitNotifierProvider.notifier).uncompleteHabit(habit.id, DateTime.now());
              _showToast("Habit uncompleted.");
            } else {
              ref.read(habitNotifierProvider.notifier).completeHabit(habit.id, DateTime.now());
              _showToast("Habit completed!");
            }
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: completed ? theme.colorScheme.primary : theme.colorScheme.onSurface.withOpacity(0.08),
            ),
            child: Icon(
              Icons.check_rounded,
              color: completed ? theme.colorScheme.onPrimary : theme.colorScheme.onSurface.withOpacity(0.6),
              size: 18,
            ),
          ),
        ),
      ),
    );
  }
}

class _AdAdjustedFabLocation extends FloatingActionButtonLocation {
  final FloatingActionButtonLocation original;
  final double adHeight;

  const _AdAdjustedFabLocation(this.original, this.adHeight);

  @override
  Offset getOffset(ScaffoldPrelayoutGeometry scaffoldGeometry) {
    final Offset originalOffset = original.getOffset(scaffoldGeometry);
    return Offset(originalOffset.dx, originalOffset.dy - adHeight);
  }
}
