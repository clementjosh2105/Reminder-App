import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/settings_provider.dart';
import '../providers/habit_provider.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  void _confirmResetData(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Reset All Data"),
          content: const Text("This action will delete all habits, streaks, history, and restore settings to default. This cannot be undone."),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              onPressed: () async {
                // Clear Hive storage
                await ref.read(storageServiceProvider).clearAllData();
                
                // Reload habits state
                ref.read(habitNotifierProvider.notifier).loadHabits();
                
                if (context.mounted) {
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("All data has been reset successfully."),
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                }
              },
              child: const Text("Reset Everything"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final settings = ref.watch(settingsProvider);
    final settingsNotifier = ref.read(settingsProvider.notifier);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Settings"),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12),
        children: [
          // 1. Appearance / Theme
          const Text(
            "Appearance",
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          Card(
            child: ListTile(
              leading: const Icon(Icons.palette_rounded),
              title: const Text("Theme Mode"),
              subtitle: Text(
                settings.themeMode[0].toUpperCase() + settings.themeMode.substring(1),
                style: TextStyle(color: theme.colorScheme.primary, fontWeight: FontWeight.w500),
              ),
              trailing: DropdownButton<String>(
                value: settings.themeMode,
                underline: const SizedBox(),
                items: const [
                  DropdownMenuItem(value: 'system', child: Text("System")),
                  DropdownMenuItem(value: 'light', child: Text("Light")),
                  DropdownMenuItem(value: 'dark', child: Text("Dark")),
                ],
                onChanged: (val) {
                  if (val != null) {
                    settingsNotifier.setThemeMode(val);
                  }
                },
              ),
            ),
          ),
          const SizedBox(height: 24),

          // 2. Notifications
          const Text(
            "Notifications",
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          Card(
            child: Column(
              children: [
                SwitchListTile(
                  title: const Text("Notification Sound"),
                  subtitle: const Text("Play alert sound for reminders"),
                  secondary: const Icon(Icons.volume_up_rounded),
                  value: settings.notificationSound,
                  onChanged: (val) {
                    settingsNotifier.setNotificationSound(val);
                  },
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.security_rounded),
                  title: const Text("Request Permissions"),
                  subtitle: const Text("Manually check notification access"),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () async {
                    await ref.read(notificationServiceProvider).requestPermissions();
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Permissions requested."),
                          behavior: SnackBarBehavior.floating,
                        ),
                      );
                    }
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // 3. AI Coach Personality
          const Text(
            "AI Coaching Settings",
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          Card(
            child: ListTile(
              leading: const Icon(Icons.face_retouching_natural_rounded),
              title: const Text("Coach Personality"),
              subtitle: Text(
                settings.motivationPersonality == 'Strict' ? 'Strict Coach' : settings.motivationPersonality,
                style: TextStyle(color: theme.colorScheme.primary, fontWeight: FontWeight.w500),
              ),
              trailing: DropdownButton<String>(
                value: settings.motivationPersonality,
                underline: const SizedBox(),
                items: const [
                  DropdownMenuItem(value: 'Friendly', child: Text("Friendly")),
                  DropdownMenuItem(value: 'Strict', child: Text("Strict Coach")),
                  DropdownMenuItem(value: 'Funny', child: Text("Funny")),
                  DropdownMenuItem(value: 'Professional', child: Text("Professional")),
                ],
                onChanged: (val) {
                  if (val != null) {
                    settingsNotifier.setMotivationPersonality(val);
                  }
                },
              ),
            ),
          ),
          const SizedBox(height: 24),

          // 4. Ads Config
          const Text(
            "Ad Settings",
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          Card(
            child: SwitchListTile(
              title: const Text("Show Ads"),
              subtitle: const Text("Support app development with occasional ads"),
              secondary: const Icon(Icons.ad_units_rounded),
              value: settings.showAds,
              onChanged: (val) {
                settingsNotifier.setShowAds(val);
              },
            ),
          ),
          const SizedBox(height: 40),

          // 5. Danger Zone
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red.shade50,
              foregroundColor: Colors.red.shade800,
              elevation: 0,
              side: BorderSide(color: Colors.red.shade100),
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
            icon: const Icon(Icons.delete_forever_rounded),
            label: const Text("Reset All Data", style: TextStyle(fontWeight: FontWeight.bold)),
            onPressed: () => _confirmResetData(context, ref),
          ),
          const SizedBox(height: 48),
        ],
      ),
    );
  }
}
