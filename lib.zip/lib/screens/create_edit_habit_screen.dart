import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import 'dart:math';
import '../core/constants.dart';
import '../models/habit.dart';
import '../providers/habit_provider.dart';

class CreateEditHabitScreen extends ConsumerStatefulWidget {
  final Habit? habit;

  const CreateEditHabitScreen({super.key, this.habit});

  @override
  ConsumerState<CreateEditHabitScreen> createState() => _CreateEditHabitScreenState();
}

class _CreateEditHabitScreenState extends ConsumerState<CreateEditHabitScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;

  late String _selectedCategory;
  late TimeOfDay _selectedTime;
  late String _recurrenceType;
  
  // Custom days list (1 = Mon, 7 = Sun)
  late List<int> _customDays;
  late int _hourlyInterval;

  final List<String> _recurrenceOptions = [
    'Once',
    'Daily',
    'Weekdays',
    'Weekends',
    'CustomDays',
    'Hourly',
  ];

  @override
  void initState() {
    super.initState();
    final h = widget.habit;
    
    _titleController = TextEditingController(text: h?.title ?? '');
    _descriptionController = TextEditingController(text: h?.description ?? '');
    _selectedCategory = h?.category ?? AppConstants.catWater;

    if (h != null) {
      final parts = h.timeOfDay.split(':');
      _selectedTime = TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
      _recurrenceType = h.recurrenceType;
      _customDays = List<int>.from(h.customDays);
      _hourlyInterval = h.hourlyInterval;
    } else {
      _selectedTime = const TimeOfDay(hour: 8, minute: 0);
      _recurrenceType = 'Daily';
      _customDays = [1, 2, 3, 4, 5]; // Default weekdays
      _hourlyInterval = 2; // Default every 2 hours
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _selectTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  void _toggleCustomDay(int dayIndex) {
    setState(() {
      if (_customDays.contains(dayIndex)) {
        if (_customDays.length > 1) {
          _customDays.remove(dayIndex);
        }
      } else {
        _customDays.add(dayIndex);
      }
    });
  }

  void _saveForm() {
    if (!_formKey.currentState!.validate()) return;

    final formattedTime = 
        "${_selectedTime.hour.toString().padLeft(2, '0')}:${_selectedTime.minute.toString().padLeft(2, '0')}";

    if (widget.habit != null) {
      // Edit existing
      final updatedHabit = widget.habit!.copyWith(
        title: _titleController.text.trim(),
        description: _descriptionController.text.trim(),
        category: _selectedCategory,
        timeOfDay: formattedTime,
        recurrenceType: _recurrenceType,
        customDays: _customDays,
        hourlyInterval: _hourlyInterval,
      );
      
      ref.read(habitNotifierProvider.notifier).updateHabit(updatedHabit);
    } else {
      // Create new
      final uuid = const Uuid().v4();
      final notificationId = Random().nextInt(1000000) + 1; // Secure random notification ID
      
      final newHabit = Habit(
        id: uuid,
        title: _titleController.text.trim(),
        description: _descriptionController.text.trim(),
        category: _selectedCategory,
        timeOfDay: formattedTime,
        recurrenceType: _recurrenceType,
        customDays: _customDays,
        hourlyInterval: _hourlyInterval,
        isEnabled: true,
        notificationId: notificationId,
        createdAt: DateTime.now(),
        completedDates: [],
        currentStreak: 0,
        longestStreak: 0,
      );

      ref.read(habitNotifierProvider.notifier).addHabit(newHabit);
    }

    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isEditing = widget.habit != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? "Edit Habit" : "Create Habit"),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Title input
            TextFormField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Habit Title',
                prefixIcon: Icon(Icons.title_rounded),
              ),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return 'Please enter a title';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            
            // Description input
            TextFormField(
              controller: _descriptionController,
              decoration: const InputDecoration(
                labelText: 'Description / Goal',
                prefixIcon: Icon(Icons.description_rounded),
              ),
              maxLines: 2,
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return 'Please enter a description';
                }
                return null;
              },
            ),
            const SizedBox(height: 24),

            // Category picker
            const Text(
              "Select Category",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 55,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: AppConstants.categories.length,
                itemBuilder: (context, index) {
                  final cat = AppConstants.categories[index];
                  final isSelected = _selectedCategory == cat;
                  final color = AppConstants.getCategoryColor(cat);
                  
                  return Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: ChoiceChip(
                      label: Row(
                        children: [
                          Icon(
                            AppConstants.getCategoryIcon(cat),
                            size: 18,
                            color: isSelected ? Colors.white : color,
                          ),
                          const SizedBox(width: 6),
                          Text(cat),
                        ],
                      ),
                      selected: isSelected,
                      onSelected: (selected) {
                        if (selected) {
                          setState(() {
                            _selectedCategory = cat;
                          });
                        }
                      },
                      selectedColor: color,
                      labelStyle: TextStyle(
                        color: isSelected ? Colors.white : Colors.white.withOpacity(0.5),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 24),

            // Time Selector
            Card(
              elevation: 0,
              color: theme.colorScheme.primary.withOpacity(0.05),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: BorderSide(color: theme.colorScheme.primary.withOpacity(0.1)),
              ),
              child: ListTile(
                leading: Icon(Icons.access_time_rounded, color: theme.colorScheme.primary),
                title: const Text("Reminder Time"),
                subtitle: Text(
                  _selectedTime.format(context),
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: theme.colorScheme.primary,
                  ),
                ),
                trailing: TextButton(
                  onPressed: _selectTime,
                  child: const Text("Change"),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Recurrence Type Dropdown
            DropdownButtonFormField<String>(
              value: _recurrenceType,
              decoration: const InputDecoration(
                labelText: 'Repeat Schedule',
                prefixIcon: Icon(Icons.repeat_rounded),
              ),
              items: _recurrenceOptions.map((opt) {
                return DropdownMenuItem<String>(
                  value: opt,
                  child: Text(opt == 'CustomDays' ? 'Custom Days' : opt == 'Once' ? 'Once (Today/Tomorrow)' : opt),
                );
              }).toList(),
              onChanged: (val) {
                if (val != null) {
                  setState(() {
                    _recurrenceType = val;
                  });
                }
              },
            ),
            
            // Conditional forms: CustomDays
            if (_recurrenceType == 'CustomDays') ...[
              const SizedBox(height: 24),
              const Text(
                "Select Days of Week",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildDayBadge(1, 'M', theme),
                  _buildDayBadge(2, 'T', theme),
                  _buildDayBadge(3, 'W', theme),
                  _buildDayBadge(4, 'T', theme),
                  _buildDayBadge(5, 'F', theme),
                  _buildDayBadge(6, 'S', theme),
                  _buildDayBadge(7, 'S', theme),
                ],
              ),
            ],

            // Conditional forms: Hourly
            if (_recurrenceType == 'Hourly') ...[
              const SizedBox(height: 24),
              DropdownButtonFormField<int>(
                value: _hourlyInterval,
                decoration: const InputDecoration(
                  labelText: 'Repeat Every X Hours',
                  prefixIcon: Icon(Icons.hourglass_empty_rounded),
                ),
                items: [1, 2, 3, 4, 6, 8, 12].map((interval) {
                  return DropdownMenuItem<int>(
                    value: interval,
                    child: Text("Every $interval Hour${interval > 1 ? 's' : ''}"),
                  );
                }).toList(),
                onChanged: (val) {
                  if (val != null) {
                    setState(() {
                      _hourlyInterval = val;
                    });
                  }
                },
              ),
            ],

            const SizedBox(height: 40),

            // Save Button
            ElevatedButton(
              onPressed: _saveForm,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 18),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              child: Text(
                isEditing ? "Save Changes" : "Create Reminder",
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDayBadge(int dayIndex, String label, ThemeData theme) {
    final isSelected = _customDays.contains(dayIndex);
    
    return InkWell(
      onTap: () => _toggleCustomDay(dayIndex),
      borderRadius: BorderRadius.circular(20),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 40,
        height: 40,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: isSelected ? theme.colorScheme.primary : theme.colorScheme.onSurface.withOpacity(0.08),
          shape: BoxShape.circle,
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : theme.colorScheme.onSurface,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
