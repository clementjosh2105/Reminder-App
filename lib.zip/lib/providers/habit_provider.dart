import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/habit.dart';
import '../repositories/habit_repository.dart';
import '../services/notification_service.dart';
import '../services/motivation_service.dart';
import '../services/admob_service.dart';

// ---------------------------------------------------------------------------
// Infrastructure providers — all overridden in main.dart via ProviderScope.
// The factory bodies throw so a missing override is caught immediately.
// ---------------------------------------------------------------------------

final notificationServiceProvider = Provider<NotificationService>((ref) {
  throw UnimplementedError('notificationServiceProvider must be overridden in main.dart');
});

final motivationServiceProvider = Provider<MotivationService>((ref) {
  return MotivationService(); // stateless, safe to construct here
});

final admobServiceProvider = Provider<AdMobService>((ref) {
  throw UnimplementedError('admobServiceProvider must be overridden in main.dart');
});

final habitRepositoryProvider = Provider<HabitRepository>((ref) {
  throw UnimplementedError('habitRepositoryProvider must be overridden in main.dart');
});

// State Notifier for Habits
class HabitNotifier extends StateNotifier<List<Habit>> {
  final HabitRepository _repository;

  HabitNotifier(this._repository) : super([]) {
    loadHabits();
  }

  void loadHabits() {
    state = _repository.getHabits();
  }

  Future<void> addHabit(Habit habit) async {
    await _repository.saveHabit(habit);
    loadHabits();
  }

  Future<void> updateHabit(Habit habit) async {
    await _repository.saveHabit(habit);
    loadHabits();
  }

  Future<void> deleteHabit(String id) async {
    await _repository.deleteHabit(id);
    loadHabits();
  }

  Future<void> toggleHabit(String id) async {
    await _repository.toggleHabit(id);
    loadHabits();
  }

  Future<void> completeHabit(String id, DateTime date) async {
    await _repository.completeHabit(id, date);
    loadHabits();
  }

  Future<void> uncompleteHabit(String id, DateTime date) async {
    await _repository.uncompleteHabit(id, date);
    loadHabits();
  }

  Future<void> snoozeHabit(String id, int minutes) async {
    await _repository.snoozeHabit(id, minutes);
    loadHabits();
  }

  Future<void> skipHabit(String id) async {
    await _repository.skipHabit(id);
    loadHabits();
  }
}

final habitNotifierProvider = StateNotifierProvider<HabitNotifier, List<Habit>>((ref) {
  final repository = ref.watch(habitRepositoryProvider);
  return HabitNotifier(repository);
});

// --- DERIVED PROVIDERS ---

// Habits scheduled for today
final todayHabitsProvider = Provider<List<Habit>>((ref) {
  final habits = ref.watch(habitNotifierProvider);
  final today = DateTime.now();
  
  return habits.where((habit) {
    if (!habit.isEnabled) return false;
    
    switch (habit.recurrenceType) {
      case 'Once':
        // Once is scheduled for today if created today, or if it hasn't been completed yet.
        final todayStr = _formatDate(today);
        final createdToday = _formatDate(habit.createdAt) == todayStr;
        return createdToday || habit.completedDates.isEmpty || habit.completedDates.contains(todayStr);
      case 'Daily':
      case 'Hourly':
        return true;
      case 'Weekdays':
        return today.weekday >= 1 && today.weekday <= 5;
      case 'Weekends':
        return today.weekday == 6 || today.weekday == 7;
      case 'CustomDays':
        return habit.customDays.contains(today.weekday);
      default:
        return true;
    }
  }).toList();
});

// Completion rate for today's habits
final todayCompletionRateProvider = Provider<double>((ref) {
  final todayHabits = ref.watch(todayHabitsProvider);
  if (todayHabits.isEmpty) return 0.0;
  
  final completedCount = todayHabits.where((h) => h.isCompletedToday()).length;
  return completedCount / todayHabits.length;
});

// Streaks and general stats provider
class StreakStats {
  final int currentStreak;
  final int longestStreak;
  final int activeStreaksCount;
  final int completedTodayCount;

  StreakStats({
    required this.currentStreak,
    required this.longestStreak,
    required this.activeStreaksCount,
    required this.completedTodayCount,
  });
}

final streakStatsProvider = Provider<StreakStats>((ref) {
  final habits = ref.watch(habitNotifierProvider);
  
  int maxCurrent = 0;
  int maxLongest = 0;
  int activeCount = 0;
  int completedToday = 0;
  
  for (final habit in habits) {
    if (habit.currentStreak > maxCurrent) {
      maxCurrent = habit.currentStreak;
    }
    if (habit.longestStreak > maxLongest) {
      maxLongest = habit.longestStreak;
    }
    if (habit.currentStreak > 0) {
      activeCount++;
    }
    if (habit.isCompletedToday()) {
      completedToday++;
    }
  }
  
  return StreakStats(
    currentStreak: maxCurrent,
    longestStreak: maxLongest,
    activeStreaksCount: activeCount,
    completedTodayCount: completedToday,
  );
});

// Helper formatted date
String _formatDate(DateTime date) {
  return "${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";
}
