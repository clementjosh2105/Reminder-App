import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/storage_service.dart';

class SettingsState {
  final String themeMode;
  final bool notificationSound;
  final String motivationPersonality;
  final bool completedOnboarding;
  final bool showAds;

  SettingsState({
    required this.themeMode,
    required this.notificationSound,
    required this.motivationPersonality,
    required this.completedOnboarding,
    required this.showAds,
  });

  SettingsState copyWith({
    String? themeMode,
    bool? notificationSound,
    String? motivationPersonality,
    bool? completedOnboarding,
    bool? showAds,
  }) {
    return SettingsState(
      themeMode: themeMode ?? this.themeMode,
      notificationSound: notificationSound ?? this.notificationSound,
      motivationPersonality: motivationPersonality ?? this.motivationPersonality,
      completedOnboarding: completedOnboarding ?? this.completedOnboarding,
      showAds: showAds ?? this.showAds,
    );
  }
}

// Must be overridden in main.dart with the already-initialized StorageService instance.
final storageServiceProvider = Provider<StorageService>((ref) {
  throw UnimplementedError('storageServiceProvider must be overridden in main.dart');
});

class SettingsNotifier extends StateNotifier<SettingsState> {
  final StorageService _storageService;

  SettingsNotifier(this._storageService)
      : super(SettingsState(
          themeMode: _storageService.getThemeMode(),
          notificationSound: _storageService.getNotificationSound(),
          motivationPersonality: _storageService.getMotivationPersonality(),
          completedOnboarding: _storageService.hasCompletedOnboarding(),
          showAds: _storageService.getShowAds(),
        ));

  Future<void> setThemeMode(String themeMode) async {
    await _storageService.setThemeMode(themeMode);
    state = state.copyWith(themeMode: themeMode);
  }

  Future<void> setNotificationSound(bool enabled) async {
    await _storageService.setNotificationSound(enabled);
    state = state.copyWith(notificationSound: enabled);
  }

  Future<void> setMotivationPersonality(String personality) async {
    await _storageService.setMotivationPersonality(personality);
    state = state.copyWith(motivationPersonality: personality);
  }

  Future<void> completeOnboarding() async {
    await _storageService.setCompletedOnboarding(true);
    state = state.copyWith(completedOnboarding: true);
  }

  Future<void> setShowAds(bool enabled) async {
    await _storageService.setShowAds(enabled);
    state = state.copyWith(showAds: enabled);
  }
}

final settingsProvider = StateNotifierProvider<SettingsNotifier, SettingsState>((ref) {
  final storage = ref.watch(storageServiceProvider);
  return SettingsNotifier(storage);
});
