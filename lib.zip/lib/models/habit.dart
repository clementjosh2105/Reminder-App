import 'package:hive/hive.dart';

part 'habit.g.dart';

@HiveType(typeId: 0)
class Habit extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String title;

  @HiveField(2)
  final String description;

  @HiveField(3)
  final String category;

  @HiveField(4)
  final String timeOfDay; // Format: "HH:mm"

  @HiveField(5)
  final String recurrenceType; // "Once", "Daily", "Weekdays", "Weekends", "CustomDays", "Hourly"

  @HiveField(6)
  final List<int> customDays; // 1 = Monday, 7 = Sunday

  @HiveField(7)
  final int hourlyInterval; // X hours

  @HiveField(8)
  final bool isEnabled;

  @HiveField(9)
  final int notificationId;

  @HiveField(10)
  final DateTime createdAt;

  @HiveField(11)
  final List<String> completedDates; // Format: "YYYY-MM-DD"

  @HiveField(12)
  final int currentStreak;

  @HiveField(13)
  final int longestStreak;

  Habit({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.timeOfDay,
    required this.recurrenceType,
    required this.customDays,
    required this.hourlyInterval,
    required this.isEnabled,
    required this.notificationId,
    required this.createdAt,
    required this.completedDates,
    required this.currentStreak,
    required this.longestStreak,
  });

  // Factory constructor for creating a new habit with default stats
  factory Habit.create({
    required String id,
    required String title,
    required String description,
    required String category,
    required String timeOfDay,
    required String recurrenceType,
    required List<int> customDays,
    required int hourlyInterval,
    required int notificationId,
  }) {
    return Habit(
      id: id,
      title: title,
      description: description,
      category: category,
      timeOfDay: timeOfDay,
      recurrenceType: recurrenceType,
      customDays: customDays,
      hourlyInterval: hourlyInterval,
      isEnabled: true,
      notificationId: notificationId,
      createdAt: DateTime.now(),
      completedDates: [],
      currentStreak: 0,
      longestStreak: 0,
    );
  }

  // CopyWith helper to create modified copies of Habit (for immutable-like patterns)
  Habit copyWith({
    String? title,
    String? description,
    String? category,
    String? timeOfDay,
    String? recurrenceType,
    List<int>? customDays,
    int? hourlyInterval,
    bool? isEnabled,
    int? notificationId,
    List<String>? completedDates,
    int? currentStreak,
    int? longestStreak,
  }) {
    return Habit(
      id: id,
      title: title ?? this.title,
      description: description ?? this.description,
      category: category ?? this.category,
      timeOfDay: timeOfDay ?? this.timeOfDay,
      recurrenceType: recurrenceType ?? this.recurrenceType,
      customDays: customDays ?? this.customDays,
      hourlyInterval: hourlyInterval ?? this.hourlyInterval,
      isEnabled: isEnabled ?? this.isEnabled,
      notificationId: notificationId ?? this.notificationId,
      createdAt: createdAt,
      completedDates: completedDates ?? this.completedDates,
      currentStreak: currentStreak ?? this.currentStreak,
      longestStreak: longestStreak ?? this.longestStreak,
    );
  }

  // Helper getters for statistics
  bool isCompletedOn(DateTime date) {
    final dateString = _formatDate(date);
    return completedDates.contains(dateString);
  }

  bool isCompletedToday() {
    return isCompletedOn(DateTime.now());
  }

  double getCompletionRate() {
    if (completedDates.isEmpty) return 0.0;
    final totalDays = DateTime.now().difference(createdAt).inDays + 1;
    if (totalDays <= 0) return 1.0;
    return (completedDates.length / totalDays).clamp(0.0, 1.0);
  }

  static String _formatDate(DateTime date) {
    return "${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";
  }
}
